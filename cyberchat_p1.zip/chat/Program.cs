﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Media;
using ai_chat;

namespace ai_chat
{// The start of namespace







    public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Display ASCII logo in the console
                DisplayLogoImage();

                // Generate and play voice greeting
                new VoiceGreetingGenerator();

                PlayVoiceGreeting();

                // Get user name with comprehensive validation
                Console.WriteLine("\n" + new string('=', 70));
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Welcome to the Cybersecurity Awareness Bot!");
                Console.ResetColor();
                Console.WriteLine(new string('=', 70) + "\n");

                string userName = GetValidatedUserName();

                // Personalized greeting with engagement
                DisplayEnhancedPersonalizedGreeting(userName);

                // Start chatbot interaction
                ChatbotManager chatbot = new ChatbotManager(userName);
                chatbot.StartConversation();
            }
            catch (Exception ex)
            {
                ConsoleUIFormatter.DisplayError($"Critical Application Error: {ex.Message}");
                ConsoleUIFormatter.DisplayWarning("The application encountered an unexpected error and will now close.");
            }
        }

        /// <summary>
        /// Displays the ASCII logo in the console window.
        /// Creates an engaging visual introduction to the application.
        /// </summary>
        static void DisplayLogoImage()
        {
            try
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;

                string[] asciiLogo = new string[]
                {
                    "╔══════════════════════════════════════════════════════════════════╗",
                    "║                                                                  ║",
                    "║   ██████╗ ██╗   ██╗███████╗███████╗ ██████╗ ███████╗███████╗     ║",
                    "║  ██╔═══██╗██║   ██║██╔════╝██╔════╝██╔═══██╗██╔════╝██╔════╝     ║",
                    "║  ██║   ██║██║   ██║█████╗  ███████╗██║   ██║█████╗  ███████╗     ║",
                    "║  ██║   ██║██║   ██║██╔══╝  ╚════██║██║   ██║██╔══╝  ╚════██║     ║",
                    "║  ╚██████╔╝╚██████╔╝███████╗███████║╚██████╔╝███████╗███████║     ║",
                    "║   ╚═════╝  ╚═════╝ ╚══════╝╚══════╝ ╚═════╝ ╚══════╝╚══════╝     ║",
                    "║                                                                  ║",
                    "║                       ███████╗ █████╗ ██████╗                    ║",
                    "║                       ██╔════╝██╔══██╗██╔══██╗                   ║",
                    "║                       ███████╗███████║██████╔╝                   ║",
                    "║                       ╚════██║██╔══██║██╔══██╗                   ║",
                    "║                       ███████║██║  ██║██║  ██║                   ║",
                    "║                                                                  ║",
                    "║                   CYBERSECURITY AWARENESS BOT                    ║",
                    "║                                                                  ║",
                    "║            Your Personal Security Guardian & Educator            ║",
                    "║                    Stay Safe. Stay Informed.                     ║",
                    "║                                                                  ║",
                    "╚══════════════════════════════════════════════════════════════════╝"
                };

                foreach (string line in asciiLogo)
                {
                    Console.WriteLine(line);
                    System.Threading.Thread.Sleep(30);
                }

                Console.ResetColor();
                System.Threading.Thread.Sleep(500);
            }
            catch (Exception ex)
            {
                ConsoleUIFormatter.DisplayWarning($"⚠ Could not display logo: {ex.Message}");
            }
        }

        /// <summary>
        /// Gets the user's name with comprehensive validation.
        /// Validates input length, character types, and provides helpful feedback.
        /// </summary>
        /// <returns>Valid user name string</returns>
        static string GetValidatedUserName()
        {
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("Please enter your name (2-50 characters): ");
                Console.ResetColor();

                string input = Console.ReadLine();

                // Validate input using InputValidator class
                string validationResult = InputValidator.ValidateName(input);

                if (validationResult != "valid")
                {
                    ConsoleUIFormatter.DisplayWarning(validationResult);
                    continue;
                }

                return input?.Trim() ?? string.Empty;
            }
        }

        /// <summary>
        /// Plays the voice greeting audio file with error handling.
        /// Gracefully degrades if audio file is unavailable.
        /// </summary>
        static void PlayVoiceGreeting()
        {
            try
            {
                string greetingPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "greeting.wav");

                if (File.Exists(greetingPath))
                {
                    using (SoundPlayer player = new SoundPlayer(greetingPath))
                    {
                        ConsoleUIFormatter.DisplayInfo("\n[ Playing voice greeting...]");
                        player.PlaySync();
                        ConsoleUIFormatter.DisplaySuccess("Voice greeting completed.");
                    }
                }
                else
                {
                    ConsoleUIFormatter.DisplayWarning("[ Voice greeting file not found. Continuing without audio.]");
                }
            }
            catch (Exception ex)
            {
                ConsoleUIFormatter.DisplayWarning($"[ Voice greeting unavailable: {ex.Message}]");
            }
        }

        /// <summary>
        /// Displays an enhanced, personalized welcome message to the user.
        /// Creates a professional and engaging first impression.
        /// </summary>
        /// <param name="userName">The name of the user</param>
        static void DisplayEnhancedPersonalizedGreeting(string userName)
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;

            Console.WriteLine("╔═══════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║                                                                   ║");
            Console.WriteLine($"║  Hello, {userName}!".PadRight(70) + "║");
            Console.WriteLine("║                                                                   ║");
            Console.WriteLine("║  Welcome to the Cybersecurity Awareness Bot!                      ║");
            Console.WriteLine("║  I'm here to help you learn cybersecurity best practices.          ║");
            Console.WriteLine("║  Together, we'll explore how to stay safe in the digital world.   ║");
            Console.WriteLine("║                                                                   ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════════════════════╝");

            Console.ResetColor();
        }
    }
}

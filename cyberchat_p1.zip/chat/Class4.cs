﻿using System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Comprehensive input validation and exception handling utility class.
/// Ensures all user inputs are validated for security and correctness.
/// Provides detailed error messages to guide users.
/// </summary>
public static class InputValidator
{
    /// <summary>
    /// Validates user name input with comprehensive checks.
    /// </summary>
    /// <param name="input">The user name input to validate</param>
    /// <returns>Validation result message ("valid" if passes, error message if fails)</returns>
    public static string ValidateName(string input)
    {
        try
        {
            // Check for null or empty input
            if (string.IsNullOrEmpty(input))
            {
                return "Name cannot be empty. Please enter your name.";
            }

            // Check for whitespace only
            if (string.IsNullOrWhiteSpace(input))
            {
                return "Name cannot contain only spaces. Please enter a valid name.";
            }

            // Trim and check minimum length
            string trimmedInput = input.Trim();
            if (trimmedInput.Length < 2)
            {
                return $"Name must be at least 2 characters long. You entered {trimmedInput.Length} character(s).";
            }

            // Check maximum length
            if (trimmedInput.Length > 50)
            {
                return $"Name must not exceed 50 characters. You entered {trimmedInput.Length} character(s).";
            }

            // Check for invalid characters (allow letters, spaces, hyphens, apostrophes)
            foreach (char c in trimmedInput)
            {
                if (!char.IsLetter(c) && c != ' ' && c != '-' && c != '\'' && c != '.')
                {
                    return $"Name contains invalid character '{c}'. Only letters, spaces, hyphens, apostrophes, and periods are allowed.";
                }
            }

            return "valid";
        }
        catch (Exception ex)
        {
            return $"An error occurred during validation: {ex.Message}";
        }
    }

    /// <summary>
    /// Validates chat message input.
    /// </summary>
    /// <param name="input">The chat message to validate</param>
    /// <returns>Validation result message</returns>
    public static string ValidateChatMessage(string input)
    {
        try
        {
            if (string.IsNullOrEmpty(input))
            {
                return "Message cannot be empty.";
            }

            if (string.IsNullOrWhiteSpace(input))
            {
                return "Message cannot contain only spaces.";
            }

            if (input.Length > 500)
            {
                return "Message is too long. Please keep it under 500 characters.";
            }

            return "valid";
        }
        catch (Exception ex)
        {
            return $"Validation error: {ex.Message}";
        }
    }

    /// <summary>
    /// Validates command input with security checks.
    /// </summary>
    /// <param name="command">The command to validate</param>
    /// <returns>Validation result message</returns>
    public static string ValidateCommand(string command)
    {
        try
        {
            if (string.IsNullOrEmpty(command))
            {
                return "Command cannot be empty.";
            }

            if (command.Length > 100)
            {
                return "Command is too long.";
            }

            return "valid";
        }
        catch (Exception ex)
        {
            return $"Validation error: {ex.Message}";
        }
    }

    /// <summary>
    /// Safely parses string to integer with error handling.
    /// </summary>
    /// <param name="input">The input string to parse</param>
    /// <param name="result">The parsed integer result</param>
    /// <returns>True if parse successful, false otherwise</returns>
    public static bool TrySafeParseInt(string input, out int result)
    {
        result = 0;
        try
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return false;
            }

            return int.TryParse(input, out result);
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Safely handles exceptions with user-friendly error messages.
    /// </summary>
    /// <param name="ex">The exception to handle</param>
    /// <returns>User-friendly error message</returns>
    public static string HandleException(Exception ex)
    {
        if (ex is ArgumentException argEx)
        {
            return $"Invalid input: {argEx.Message}";
        }
        else if (ex is InvalidOperationException invOpEx)
        {
            return $"Operation not allowed: {invOpEx.Message}";
        }
        else if (ex is OutOfMemoryException)
        {
            return "System memory error. Please try again.";
        }
        else if (ex is IOException ioEx)
        {
            return $"File system error: {ioEx.Message}";
        }
        else
        {
            return $"An unexpected error occurred: {ex.Message}";
        }
    }
}

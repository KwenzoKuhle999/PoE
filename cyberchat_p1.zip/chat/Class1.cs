﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Manages the chatbot conversation logic, response generation, and user engagement.
/// Implements a comprehensive response system covering cybersecurity topics.
/// </summary>
public class ChatbotManager
{
    private string _userName;
    private Dictionary<string, string> _responses;
    private int _messageCount;
    private DateTime _sessionStartTime;

    /// <summary>
    /// Initializes a new instance of the ChatbotManager class.
    /// </summary>
    /// <param name="userName">The name of the user</param>
    public ChatbotManager(string userName)
    {
        _userName = userName;
        _messageCount = 0;
        _sessionStartTime = DateTime.Now;
        InitializeResponses();
    }

    /// <summary>
    /// Initializes the response database with comprehensive cybersecurity Q&A pairs.
    /// Includes 15+ detailed responses covering essential security topics.
    /// </summary>
    private void InitializeResponses()
    {
        _responses = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            // Greeting responses - Engaging and professional
            { "how are you",
                $"I'm functioning perfectly, {_userName}! Thank you for asking. I'm actively monitoring cybersecurity threats and ready to help you stay safe online. " +
                "What cybersecurity topic would you like to explore today? I can help with password safety, phishing prevention, malware protection, safe browsing, 2FA, or social engineering awareness." },

            { "what's your purpose",
                "My purpose is to educate you about cybersecurity best practices and help you become a more informed digital citizen. " +
                "I provide comprehensive guidance on protecting yourself from cyber threats, securing your accounts, and making safe online decisions. " +
                "Your digital security is my priority!" },

            { "what can i ask you about",
                $"Great question, {_userName}! I specialize in these cybersecurity areas:\n\n" +
                "   Password Safety - Creating unbreakable passwords\n" +
                "   Phishing Prevention - Identifying deceptive attacks\n" +
                "   Safe Browsing - Secure internet practices\n" +
                "   Malware Protection - Defending against harmful software\n" +
                "   Two-Factor Authentication (2FA) - Enhanced security layers\n" +
                "   Social Engineering - Recognizing manipulation tactics\n" +
                "   Account Security - Protecting your digital identity\n" +
                "   Email Security - Safe communication practices\n\n" +
                "Type 'help' to see all available commands, or ask me anything about cybersecurity!" },

            // Password Safety - Comprehensive with actionable steps
            { "password",
                $" PASSWORD SAFETY MASTERCLASS for {_userName}:\n\n" +
                " CREATE STRONG PASSWORDS:\n" +
                "  ✓ Length: Minimum 12-16 characters (longer is better)\n" +
                "  ✓ Complexity: Mix uppercase (A-Z), lowercase (a-z), numbers (0-9), and symbols (!@#$%)\n" +
                "  ✓ Uniqueness: Use different passwords for EVERY account\n" +
                "  ✓ Randomness: Avoid dictionary words and personal information\n" +
                "  ✓ No patterns: Don't use sequential numbers or keyboard patterns\n\n" +
                " PASSWORD MANAGEMENT:\n" +
                "  ✓ Never share passwords with anyone\n" +
                "  ✓ Don't write passwords on paper or sticky notes\n" +
                "  ✓ Change passwords immediately if compromised\n" +
                "  ✓ Use a reputable password manager (1Password, LastPass, Bitwarden)\n" +
                "  ✓ Enable 2FA for critical accounts\n\n" +
                " NEVER DO THIS:\n" +
                "  ✗ Use family names, birthdays, or pet names\n" +
                "  ✗ Reuse passwords across multiple sites\n" +
                "  ✗ Write passwords where others can find them\n" +
                "  ✗ Click 'Remember Password' on public computers\n" +
                "  ✗ Share passwords via email or messages" },

            // Phishing Prevention - Detection and protection
            { "phishing",
                $" PHISHING PREVENTION GUIDE for {_userName}:\n\n" +
                "What is Phishing?\n" +
                "Phishing is a sophisticated cyber attack where criminals pose as legitimate organizations " +
                "to steal your sensitive information like passwords, credit card details, or personal data.\n\n" +
                " RED FLAGS - Warning Signs of Phishing:\n" +
                "  • Unexpected emails asking for passwords or personal information\n" +
                "  • Sender email addresses that look slightly wrong or suspicious\n" +
                "  • Urgent language like 'ACT NOW!' or 'Account will be closed!'\n" +
                "  • Grammar, spelling, or formatting errors in official emails\n" +
                "  • Suspicious links (hover to see real URL before clicking)\n" +
                "  • Suspicious attachments or requests to download files\n" +
                "  • Generic greetings like 'Dear Customer' instead of your name\n" +
                "  • Requests to verify information you already provided\n\n" +
                " PROTECTION STRATEGIES:\n" +
                "  ✓ Never click links in suspicious emails - go directly to the website\n" +
                "  ✓ Hover over links to verify the actual URL destination\n" +
                "  ✓ Contact organizations directly using official contact information\n" +
                "  ✓ Keep your email account secure with a strong password and 2FA\n" +
                "  ✓ Report phishing emails to the organization and your email provider\n" +
                "  ✓ Use email filters and spam detection tools\n" +
                "  ✓ Keep antivirus and anti-phishing software updated\n" +
                "  ✓ Be skeptical of unexpected requests, even from known senders\n\n" +
                "💡 If you received a phishing email, report it immediately!" },

            // Safe Browsing - Comprehensive online safety
            { "browsing",
                $" SAFE BROWSING PRACTICES for {_userName}:\n\n" +
                " HTTPS & ENCRYPTION:\n" +
                "  ✓ Look for the padlock icon (🔒) in the address bar\n" +
                "  ✓ URLs should begin with 'https://' (not 'http://')\n" +
                "  ✓ Use HTTPS sites for all sensitive transactions\n" +
                "  ✓ Avoid entering personal data on non-HTTPS sites\n" +
                "  ✓ Green address bar indicates verified SSL certificate\n\n" +
                " BROWSER SECURITY:\n" +
                "  ✓ Keep your browser updated with latest security patches\n" +
                "  ✓ Use reputable browsers (Chrome, Firefox, Edge)\n" +
                "  ✓ Disable unnecessary browser extensions\n" +
                "  ✓ Regularly clear cookies, cache, and browsing history\n" +
                "  ✓ Use privacy mode for sensitive browsing sessions\n\n" +
                " NETWORK SAFETY:\n" +
                "  ✓ Avoid public WiFi for sensitive transactions\n" +
                "  ✓ Use a VPN (Virtual Private Network) on public networks\n" +
                "  ✓ Don't enable automatic connection to open networks\n" +
                "  ✓ Turn off WiFi and Bluetooth when not in use\n" +
                "  ✓ Always verify WiFi network names before connecting\n\n" +
                " DOWNLOAD SAFETY:\n" +
                "  ✓ Only download from official, trusted sources\n" +
                "  ✓ Scan downloaded files with antivirus software\n" +
                "  ✓ Verify file checksums before installation\n" +
                "  ✓ Avoid downloading from suspicious websites\n" +
                "  ✓ Be cautious with executable files (.exe, .dmg, .zip)\n\n" +
                " ADDITIONAL PROTECTIONS:\n" +
                "  ✓ Install and maintain reputable antivirus software\n" +
                "  ✓ Use a firewall to block unauthorized access\n" +
                "  ✓ Check privacy settings on all accounts\n" +
                "  ✓ Use ad blockers to prevent malicious ads\n" +
                "  ✓ Keep all software and operating systems updated" },

            // Malware Protection - Types and defenses
            { "malware",
                $" MALWARE PROTECTION COMPREHENSIVE GUIDE for {_userName}:\n\n" +
                "What is Malware?\n" +
                "Malware is malicious software designed to harm your device, steal data, or compromise your security. " +
                "It includes viruses, trojans, ransomware, spyware, and worms.\n\n" +
                " TYPES OF MALWARE:\n" +
                "  • Viruses - Programs that replicate and spread to other files\n" +
                "  • Trojans - Appear legitimate but contain hidden malicious code\n" +
                "  • Ransomware - Encrypts your files and demands payment for recovery\n" +
                "  • Spyware - Secretly monitors your activity and steals information\n" +
                "  • Worms - Self-replicating programs that spread via networks\n" +
                "  • Adware - Displays unwanted advertisements and tracks behavior\n" +
                "  • Rootkits - Gain administrative access to your system\n\n" +
                " PROTECTION STRATEGIES:\n" +
                "  ✓ Use updated antivirus and anti-malware software\n" +
                "  ✓ Keep your operating system and software updated\n" +
                "  ✓ Never open attachments from unknown sources\n" +
                "  ✓ Be cautious of downloads from untrusted sites\n" +
                "  ✓ Use firewalls and security software\n" +
                "  ✓ Perform regular system scans and backups\n" +
                "  ✓ Enable automatic security updates\n" +
                "  ✓ Disable macros in Office documents\n" +
                "  ✓ Use user accounts with limited privileges\n" +
                "  ✓ Isolate infected devices immediately\n\n" +
                " IF INFECTED:\n" +
                "  1. Disconnect from the internet\n" +
                "  2. Boot into Safe Mode\n" +
                "  3. Run antivirus and anti-malware scans\n" +
                "  4. Remove detected threats\n" +
                "  5. Change all passwords from a clean device\n" +
                "  6. Monitor accounts for suspicious activity" },

            // Two-Factor Authentication - Security enhancement
            { "2fa",
                $" TWO-FACTOR AUTHENTICATION (2FA) GUIDE for {_userName}:\n\n" +
                "What is 2FA?\n" +
                "2FA adds an extra security layer requiring two forms of verification before account access. " +
                "Even if someone has your password, they cannot access your account without the second factor.\n\n" +
                " COMMON 2FA METHODS:\n" +
                "  1. SMS Text Messages - One-time code sent to your phone\n" +
                "  2. Authenticator Apps - Google Authenticator, Microsoft Authenticator, Authy\n" +
                "  3. Email Verification - Confirmation code sent to your email\n" +
                "  4. Biometric - Fingerprint, face recognition, or iris scan\n" +
                "  5. Security Keys - Physical USB devices (FIDO2 keys)\n" +
                "  6. Push Notifications - Approve/deny login from your phone\n\n" +
                " MAJOR BENEFITS:\n" +
                "  ✓ Significantly increases account security (99.9% reduction in hacks)\n" +
                "  ✓ Protects against password theft and phishing\n" +
                "  ✓ Prevents account takeover even with stolen credentials\n" +
                "  ✓ Protects sensitive data like financial and email accounts\n" +
                "  ✓ Meets compliance requirements for many organizations\n\n" +
                " RECOMMENDATIONS:\n" +
                "  ✓ Enable 2FA on ALL critical accounts (email, banking, social media)\n" +
                "  ✓ Use authenticator apps instead of SMS when possible\n" +
                "  ✓ Keep backup codes in a secure, offline location\n" +
                "  ✓ Use security keys for maximum protection\n" +
                "  ✓ Update recovery contact information\n" +
                "  ✓ Store backup authentication methods\n\n" +
                " SUPPORTED BY:\n" +
                "  • Google, Microsoft, Facebook, Twitter, LinkedIn\n" +
                "  • Banks and financial institutions\n" +
                "  • Email providers (Gmail, Outlook, Yahoo)\n" +
                "  • Social media platforms\n" +
                "  • Cloud storage services" },

            // Social Engineering - Manipulation tactics
            { "social engineering",
                $" SOCIAL ENGINEERING AWARENESS GUIDE for {_userName}:\n\n" +
                "What is Social Engineering?\n" +
                "Social engineering is psychological manipulation used to trick people into divulging confidential information " +
                "or performing security-compromising actions.\n\n" +
                " COMMON SOCIAL ENGINEERING TACTICS:\n" +
                "  • Pretexting - Creating a false scenario to obtain information\n" +
                "  • Baiting - Offering something enticing to compromise security\n" +
                "  • Quid Pro Quo - Offering service in exchange for information\n" +
                "  • Tailgating - Following someone into restricted areas\n" +
                "  • Phishing - Fake emails requesting sensitive information\n" +
                "  • Vishing - Voice phishing via phone calls\n" +
                "  • Authority Manipulation - Impersonating authority figures\n" +
                "  • Trust Exploitation - Leveraging existing relationships\n\n" +
                " PROTECTION STRATEGIES:\n" +
                "  ✓ Verify identities before sharing information\n" +
                "  ✓ Be suspicious of unsolicited requests\n" +
                "  ✓ Never share passwords or sensitive data\n" +
                "  ✓ Hang up and call back using official numbers\n" +
                "  ✓ Don't let urgency force your decisions\n" +
                "  ✓ Report suspicious behavior to your organization\n" +
                "  ✓ Follow principle of least privilege\n" +
                "  ✓ Keep security policies visible and practiced" },

            // Account Security - Comprehensive protection
            { "account security",
                $" ACCOUNT SECURITY MASTERCLASS for {_userName}:\n\n" +
                "PROTECTING YOUR DIGITAL IDENTITY:\n\n" +
                " ESSENTIAL SECURITY MEASURES:\n" +
                "  1. Use unique, strong passwords for each account\n" +
                "  2. Enable two-factor authentication on critical accounts\n" +
                "  3. Regularly review account activity and login history\n" +
                "  4. Update security questions with difficult answers\n" +
                "  5. Keep recovery email and phone number current\n" +
                "  6. Use security keys for maximum protection\n" +
                "  7. Review connected apps and services periodically\n" +
                "  8. Set up account alerts for login attempts\n\n" +
                " MONITORING YOUR ACCOUNTS:\n" +
                "  ✓ Check account activity regularly (Gmail Security Checkup)\n" +
                "  ✓ Review connected devices and sign out unused ones\n" +
                "  ✓ Set up login alerts and notifications\n" +
                "  ✓ Use account recovery options\n" +
                "  ✓ Monitor credit reports (annualcreditreport.com)\n" +
                "  ✓ Set up fraud alerts or credit freezes\n" +
                "  ✓ Use identity theft monitoring services\n\n" +
                " IF COMPROMISED:\n" +
                "  1. Change password immediately from secure device\n" +
                "  2. Enable 2FA if not already active\n" +
                "  3. Review account activity and remove suspicious items\n" +
                "  4. Sign out all sessions and devices\n" +
                "  5. Check connected apps and remove unauthorized ones\n" +
                "  6. Update recovery information\n" +
                "  7. Contact financial institutions if needed\n" +
                "  8. File fraud reports if identity compromised" },

            // Email Security - Safe communication
            { "email",
                $" EMAIL SECURITY BEST PRACTICES for {_userName}:\n\n" +
                "EMAIL IS YOUR GATEWAY TO ACCOUNT COMPROMISE!\n\n" +
                " SECURING YOUR EMAIL ACCOUNT:\n" +
                "  ✓ Use a strong, unique password (16+ characters)\n" +
                "  ✓ Enable 2FA on your email (highest priority)\n" +
                "  ✓ Set up recovery phone and backup email\n" +
                "  ✓ Review connected apps regularly\n" +
                "  ✓ Enable security alerts for unusual activity\n" +
                "  ✓ Set up forwarding alerts\n" +
                "  ✓ Use email encryption for sensitive messages\n\n" +
                " SAFE EMAIL PRACTICES:\n" +
                "  ✓ Never open attachments from unknown senders\n" +
                "  ✓ Don't click links in suspicious emails\n" +
                "  ✓ Verify sender address carefully (look for subtle fakes)\n" +
                "  ✓ Hover over links to see actual URL\n" +
                "  ✓ Use spam filters and block unwanted senders\n" +
                "  ✓ Report phishing emails\n" +
                "  ✓ Use separate emails for different purposes\n" +
                "  ✓ Avoid using email for sensitive password resets\n\n" +
                " EMAIL SAFETY CHECKLIST:\n" +
                "  ✓ Your email IS your master key - protect it well!\n" +
                "  ✓ Use strong password + 2FA always\n" +
                "  ✓ Check connected apps regularly\n" +
                "  ✓ Enable security alerts\n" +
                "  ✓ Review account activity monthly" },

            // Help command - Comprehensive listing
            { "help",
                $" COMPLETE COMMAND REFERENCE for {_userName}:\n\n" +
                " CONVERSATION TOPICS:\n" +
                "  • 'How are you?' - Chatbot greeting\n" +
                "  • 'What's your purpose?' - Learn about the bot\n" +
                "  • 'What can I ask you about?' - See available topics\n\n" +
                " CYBERSECURITY TOPICS (Ask about any of these):\n" +
                "  • 'Password' or 'Password Safety' - Strong password creation\n" +
                "  • 'Phishing' or 'Phishing Prevention' - Recognize phishing attacks\n" +
                "  • 'Browsing' or 'Safe Browsing' - Secure internet practices\n" +
                "  • 'Malware' or 'Malware Protection' - Defend against malicious software\n" +
                "  • '2FA' or 'Two-Factor Authentication' - Enhanced security layers\n" +
                "  • 'Social Engineering' - Recognize manipulation tactics\n" +
                "  • 'Account Security' - Protect your digital identity\n" +
                "  • 'Email' or 'Email Security' - Safe communication practices\n\n" +
                " BOT COMMANDS:\n" +
                "  • 'Help' - Display this help message\n" +
                "  • 'Clear' - Clear the console screen\n" +
                "  • 'Stats' - Show session statistics\n" +
                "  • 'Exit' or 'Quit' - Close the chatbot gracefully\n\n" +
                " TIPS:\n" +
                "  • Type topic names to learn more\n" +
                "  • Ask multiple questions in one message\n" +
                "  • I personalize all responses with your name\n" +
                "  • Use 'clear' if screen gets cluttered\n" +
                "  • Type 'help' anytime to see this message again" },

            // Engaging greetings
            { "hello",
                $"Hello {_userName}!  Welcome back to the Cybersecurity Awareness Bot. I'm here to help you stay safe online. " +
                "What cybersecurity topic would you like to explore today? Type 'help' to see all available topics." },

            { "hi",
                $"Hi {_userName}!  Great to see you. I'm ready to help you learn about cybersecurity. " +
                "Whether you want to know about passwords, phishing, or any other security topic, I'm here to help! Type 'help' for options." },

            // Additional cybersecurity topic
            { "data protection",
                $" DATA PROTECTION & BACKUP STRATEGIES for {_userName}:\n\n" +
                "WHY BACKUP IS CRITICAL:\n" +
                "  • Ransomware attacks encrypt all your files\n" +
                "  • Hardware failures can happen anytime\n" +
                "  • Accidental deletion is more common than you think\n" +
                "  • Natural disasters and theft can destroy devices\n\n" +
                " BACKUP BEST PRACTICES:\n" +
                "  ✓ Use the 3-2-1 backup rule:\n" +
                "    • 3 copies of your data (original + 2 backups)\n" +
                "    • 2 different storage types (hard drive + cloud)\n" +
                "    • 1 backup offsite (in case of disaster)\n" +
                "  ✓ Schedule automatic, regular backups\n" +
                "  ✓ Test restore procedures periodically\n" +
                "  ✓ Encrypt sensitive backups\n" +
                "  ✓ Store backups securely and separately\n" +
                "  ✓ Use versioning to recover old files\n\n" +
                " BACKUP SOLUTIONS:\n" +
                "  • Cloud: Google Drive, OneDrive, iCloud, Backblaze\n" +
                "  • External: USB drives, external hard drives\n" +
                "  • Network: NAS devices, network storage\n" +
                "  • Hybrid: Combination of cloud + local backup" }
        };
    }

    /// <summary>
    /// Starts the main conversation loop with the user.
    /// Handles user input, special commands, and conversation flow.
    /// </summary>
    public void StartConversation()
    {
        Console.WriteLine("\n" + new string('─', 75));
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("✓ Conversation started! Type 'help' for available commands or start asking questions.");
        Console.ResetColor();
        Console.WriteLine(new string('─', 75) + "\n");

        while (true)
        {
            try
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write($"{_userName}: ");
                Console.ResetColor();

                string userInput = Console.ReadLine();

                // Input validation
                if (string.IsNullOrWhiteSpace(userInput))
                {
                    ConsoleUIFormatter.DisplayWarning("Please enter a message to continue.");
                    continue;
                }

                // Handle clear command
                if (userInput.Equals("clear", StringComparison.OrdinalIgnoreCase))
                {
                    Console.Clear();
                    continue;
                }

                // Handle stats command
                if (userInput.Equals("stats", StringComparison.OrdinalIgnoreCase))
                {
                    DisplaySessionStatistics();
                    continue;
                }

                // Check for exit commands
                if (userInput.Equals("exit", StringComparison.OrdinalIgnoreCase) ||
                    userInput.Equals("quit", StringComparison.OrdinalIgnoreCase))
                {
                    DisplayExitMessage();
                    break;
                }

                // Get and display response
                _messageCount++;
                string response = GetResponse(userInput);
                DisplayBotResponse(response);
            }
            catch (Exception ex)
            {
                ConsoleUIFormatter.DisplayError($"An error occurred processing your message: {ex.Message}");
                ConsoleUIFormatter.DisplayWarning("Please try again or type 'help' for assistance.");
            }
        }
    }

    /// <summary>
    /// Retrieves an appropriate response based on user input.
    /// Uses intelligent matching and personalization.
    /// </summary>
    /// <param name="userInput">The user's input message</param>
    /// <returns>A personalized response string</returns>
    private string GetResponse(string userInput)
    {
        // Check for exact matches or partial matches (prioritize longer matches)
        var matchedResponses = _responses.Keys
            .Where(key => userInput.IndexOf(key, StringComparison.OrdinalIgnoreCase) >= 0)
            .OrderByDescending(key => key.Length)
            .ToList();

        if (matchedResponses.Count > 0)
        {
            string bestMatch = matchedResponses.First();
            string response = _responses[bestMatch];
            response = response.Replace("{_userName}", _userName);
            return response;
        }

        // Default response for unrecognized input
        return $"I didn't quite understand that, {_userName}. Could you rephrase or be more specific? " +
               $"I'm knowledgeable about:\n" +
               $"  • Password Safety\n" +
               $"  • Phishing Prevention\n" +
               $"  • Safe Browsing\n" +
               $"  • Malware Protection\n" +
               $"  • 2FA / Two-Factor Authentication\n" +
               $"  • Social Engineering\n" +
               $"  • Account Security\n" +
               $"  • Email Security\n" +
               $"  • Data Protection\n\n" +
               $"Type 'help' to see all available topics, or ask me anything about cybersecurity!";
    }

    /// <summary>
    /// Displays the bot's response with typing animation for engagement.
    /// </summary>
    /// <param name="response">The response message to display</param>
    private void DisplayBotResponse(string response)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write("Bot: ");
        Console.ResetColor();

        // Simulate typing effect for engagement
        foreach (char c in response)
        {
            Console.Write(c);
            System.Threading.Thread.Sleep(5); // Adjusted for better readability
        }

        Console.WriteLine("\n");
    }

    /// <summary>
    /// Displays session statistics.
    /// </summary>
    private void DisplaySessionStatistics()
    {
        TimeSpan sessionDuration = DateTime.Now - _sessionStartTime;

        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("\n" + new string('═', 70));
        Console.WriteLine("SESSION STATISTICS");
        Console.WriteLine(new string('═', 70));
        Console.WriteLine($"User: {_userName}");
        Console.WriteLine($"Messages: {_messageCount}");
        Console.WriteLine($"Session Duration: {sessionDuration.Hours}h {sessionDuration.Minutes}m {sessionDuration.Seconds}s");
        Console.WriteLine($"Session Started: {_sessionStartTime:yyyy-MM-dd HH:mm:ss}");
        Console.WriteLine(new string('═', 70) + "\n");
        Console.ResetColor();
    }

    /// <summary>
    /// Displays the exit message with session summary.
    /// </summary>
    private void DisplayExitMessage()
    {
        TimeSpan sessionDuration = DateTime.Now - _sessionStartTime;

        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine("\n" + new string('═', 70));
        Console.WriteLine("SESSION COMPLETE");
        Console.WriteLine(new string('═', 70));
        Console.WriteLine($"Thank you for chatting, {_userName}! 👋");
        Console.WriteLine($"Remember: Stay safe online and practice these cybersecurity principles daily.");
        Console.WriteLine($"\nSession Summary:");
        Console.WriteLine($"  • Total Messages: {_messageCount}");
        Console.WriteLine($"  • Session Duration: {sessionDuration.Hours}h {sessionDuration.Minutes}m {sessionDuration.Seconds}s");
        Console.WriteLine($"  • Topics Discussed: Cybersecurity Best Practices");
        Console.WriteLine($"\nStay Secure. Stay Informed. 🔒");
        Console.WriteLine(new string('═', 70) + "\n");
        Console.ResetColor();
    }
}

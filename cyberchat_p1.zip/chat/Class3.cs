﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



/// <summary>
/// Provides comprehensive formatting utilities for enhanced console user interface.
/// Handles colored text, decorative borders, and professional visual elements.
/// Ensures consistent styling throughout the application.
/// </summary>
public static class ConsoleUIFormatter
{
    /// <summary>
    /// Displays a header with decorative border and professional styling.
    /// </summary>
    /// <param name="title">The title text to display</param>
    public static void DisplayHeader(string title)
    {
        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine("╔" + new string('═', Math.Max(title.Length + 2, 60)) + "╗");
        Console.WriteLine("║ " + title.PadRight(Math.Max(title.Length, 59)) + "║");
        Console.WriteLine("╚" + new string('═', Math.Max(title.Length + 2, 60)) + "╝");
        Console.ResetColor();
    }

    /// <summary>
    /// Displays a section header with visual separator and professional formatting.
    /// </summary>
    /// <param name="sectionTitle">The section title</param>
    public static void DisplaySection(string sectionTitle)
    {
        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("▶ " + sectionTitle);
        Console.WriteLine(new string('─', sectionTitle.Length + 2));
        Console.ResetColor();
    }

    /// <summary>
    /// Displays informational text in white with clear visibility.
    /// </summary>
    /// <param name="message">The message to display</param>
    public static void DisplayInfo(string message)
    {
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine(message);
        Console.ResetColor();
    }

    /// <summary>
    /// Displays a success message in green with professional checkmark symbol.
    /// </summary>
    /// <param name="message">The success message</param>
    public static void DisplaySuccess(string message)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("✓ " + message);
        Console.ResetColor();
    }

    /// <summary>
    /// Displays a warning message in yellow with caution symbol.
    /// Provides clear visual feedback for non-critical issues.
    /// </summary>
    /// <param name="message">The warning message</param>
    public static void DisplayWarning(string message)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("⚠ " + message);
        Console.ResetColor();
    }

    /// <summary>
    /// Displays an error message in red with error symbol.
    /// Provides clear visual feedback for critical issues.
    /// </summary>
    /// <param name="message">The error message</param>
    public static void DisplayError(string message)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("✗ " + message);
        Console.ResetColor();
    }

    /// <summary>
    /// Displays a professional separator line for visual organization.
    /// </summary>
    public static void DisplaySeparator()
    {
        Console.ForegroundColor = ConsoleColor.Gray;
        Console.WriteLine(new string('─', 75));
        Console.ResetColor();
    }

    /// <summary>
    /// Displays a boxed message with decorative borders.
    /// Creates visually distinct information blocks.
    /// </summary>
    /// <param name="message">The message to display in a box</param>
    public static void DisplayBox(string message)
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        int boxWidth = Math.Min(message.Length + 4, 70);
        Console.WriteLine("┌" + new string('─', boxWidth) + "┐");
        Console.WriteLine("│ " + message.PadRight(boxWidth - 2) + "│");
        Console.WriteLine("└" + new string('─', boxWidth) + "┘");
        Console.ResetColor();
    }

    /// <summary>
    /// Displays a highlighted announcement box with special formatting.
    /// </summary>
    /// <param name="announcement">The announcement text</param>
    public static void DisplayAnnouncement(string announcement)
    {
        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine("╔" + new string('═', 68) + "╗");
        Console.WriteLine("║ " + announcement.PadRight(66) + " ║");
        Console.WriteLine("╚" + new string('═', 68) + "╝");
        Console.ResetColor();
        Console.WriteLine();
    }
}

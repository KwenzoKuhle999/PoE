﻿using System;
using System.Media;
using System.IO;

namespace ai_chat
{// The start of namespace
    public class VoiceGreetingGenerator
    {// The start of the class

        // Auto get the path directory
        private string full_path = AppDomain.CurrentDomain.BaseDirectory;

        public VoiceGreetingGenerator()
        {// The start of constructor
            // Calling greeting method
            PlayGreeting();

        }// The end of the constructor

        // Method to play the greeting sound
        private void PlayGreeting()
        {// Start of PlayGreeting method

            // Check if the path is auto collected
            Console.WriteLine(full_path);

            // Then replace the \bin\Debug with greeting.wav location
            string correct_path = full_path.Replace(@"\bin\Debug\", @"\greeting.wav");

            // Check if the path is found
            Console.WriteLine(correct_path);

            // Check if the greeting file exists
            if (File.Exists(correct_path))
            {
                // Use the SoundPlayer class to play the audio file
                // with an object name greeting_player
                SoundPlayer greeting_player = new SoundPlayer(correct_path);

                // Play the sound
                greeting_player.Play();

                ConsoleUIFormatter.DisplaySuccess(" Voice greeting playing...");
            }
            else
            {
                ConsoleUIFormatter.DisplayWarning($" Greeting file not found at: {correct_path}");
            }

        }// The end of PlayGreeting method

    }// The end of the class

}// The end of the namespace
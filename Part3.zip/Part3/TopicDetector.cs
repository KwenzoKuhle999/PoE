﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Part3
{

    public class TopicDetector
    {
        private readonly Random _random = new Random();

        public Dictionary<string, string[]> CyberResponses { get; private set; } = new Dictionary<string, string[]>()
        {
            { "phishing", new string[] {
                "Phishing is a deceptive technique where attackers mask themselves as trusted entities to steal your credentials, sensitive codes, or personal data. Think of it like a trap—they create fake login screens or urgent bank emails, hoping you'll type your secret keys into their malicious systems.",
                "At its core, phishing relies on human engineering rather than system exploits. They manipulate human trust, fear, or a sense of urgency. When someone clicks on a suspicious link or opens a fake invoice attachment without checking, they accidentally let the attacker look inside their security perimeter.",
                "Phishers are getting incredibly smart with impersonation. They copy logos, format layouts perfectly, and send emails that look exactly like they come from your colleagues or local service providers. Checking the hidden sender address field carefully is always your strongest first layer of shielding.",
                "Advanced variants include Spear Phishing, which drops generic bait in favor of highly customized, researched targeting. Attackers scour social media profiles to mention your actual projects, coworkers, or recent locations to completely bypass your natural suspicion.",
                "Phishing isn't restricted to your inbox anymore. Smishing utilizes malicious SMS text alerts with fraudulent package tracking links, while Vishing uses automated voice generation over phone calls to trick targets into reading out their temporary MFA codes over the line.",
                "A catastrophic corporate threat is BEC (Business Email Compromise). Attackers hijack or perfectly spoof an executive's corporate email account, sending urgent, top-down directives to accounting personnel demanding immediate wire transfers to hidden offshore systems."
            }},
            { "malware", new string[] {
                "Malware stands for malicious software. It is a broad term used to define unauthorized programs, background tracker viruses, hidden rootkits, or payload scripts designed entirely to access, alter, or break down an operating workspace without your knowledge.",
                "A dangerous variant of malware is Ransomware. Once this gets inside a localized system, it instantly locks and encrypts all your critical user documents. The bad actors then display a text note demanding high digital currency payments just to give you the decryption recovery pattern key.",
                "Defending your systems against malware infiltration requires real-time behavioral active scanners and regular code patches. Attackers look for tiny unpatched structural flaws in your web browsers or utilities to silently execute background processes and set up unauthorized command lines."
            }},
            { "social engineering", new string[] {
                "Social engineering is the art of manipulation where attackers exploit human psychology to trick people into divulging confidential information or performing actions that compromise security. It bypasses technical defenses by targeting the human element.",
                "Common social engineering tactics include pretexting (creating false scenarios), baiting (offering something enticing), tailgating (following authorized personnel), and quid pro quo (offering service for information).",
                "Protecting against social engineering requires awareness training, verification protocols, and a security-conscious culture where employees double-check requests, especially those asking for passwords, sensitive data, or system access."
            }},
            { "password", new string[] {
                "Password attacks include brute force attempts where attackers systematically try countless password combinations, dictionary attacks using common words, and credential stuffing reusing leaked passwords across multiple accounts.",
                "Weak passwords are the gateway to unauthorized access. Passwords like '123456', 'password', or birthdate-based combinations are cracked in milliseconds by modern computing power.",
                "Strong defenses include enforcing complex password policies, implementing multi-factor authentication, using password managers, and monitoring for unusual login patterns or failed attempts."
            }},
            { "sql injection", new string[] {
                "SQL injection is a code injection technique where attackers insert malicious SQL statements into input fields to manipulate database queries, potentially accessing, modifying, or deleting sensitive database information.",
                "For example, entering ' OR '1'='1 in a login field can bypass authentication by making the SQL query always evaluate as true, granting unauthorized access without credentials.",
                "Developers prevent SQL injection through parameterized queries, input validation, stored procedures, and using ORM frameworks that automatically escape user inputs."
            }}
        };

        private readonly Dictionary<string, string[]> _topicKeywords = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
        {
            { "phishing", new string[] { "fake email", "scam", "fraud", "suspicious link", "phish", "hacked link", "spoof" } },
            { "malware", new string[] { "virus", "trojan", "ransomware", "spyware", "worm", "infection", "corrupted file" } },
            { "SQL injection", new string[] { "SQL", "database", "injection", "code injection", "query manipulation", "database access" } },
            { "social engineering", new string[] { "manipulation", "pretexting", "baiting", "tailgating", "quid pro quo", "psychological attack" } },
            { "password", new string[] { "brute force", "dictionary attack", "credential stuffing", "weak password", "password leak", "password cracking", "password " } }
        };

        public string DetectTopicToken(string message)
        {
            foreach (var topic in _topicKeywords)
            {
                if (topic.Value.Any(word => message.Contains(word, StringComparison.OrdinalIgnoreCase))) return topic.Key;
            }
            foreach (var topic in CyberResponses)
            {
                if (message.Contains(topic.Key, StringComparison.OrdinalIgnoreCase)) return topic.Key;
            }
            return "";
        }

        public string BuildResponse(string topic, string supportPrefix)
        {
            if (!CyberResponses.ContainsKey(topic))
                return "I have lots of security data, but I don't seem to have specific records for that term yet. Let's try looking into malware or phishing rules instead.";

            string[] foundResponses = CyberResponses[topic];
            int index = _random.Next(foundResponses.Length);
            return supportPrefix + foundResponses[index];
        }
    }
}

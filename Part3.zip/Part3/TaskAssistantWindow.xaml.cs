﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualBasic;
using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;



namespace Part3
{

    public partial class TaskAssistantWindow : Window
    {
        private readonly TaskManager _taskManager;
        private readonly ReminderService _reminderService;
        private TaskItem _selected;

        public TaskAssistantWindow(TaskManager manager, ReminderService reminderService)
        {
            InitializeComponent();
            _taskManager = manager ?? throw new ArgumentNullException(nameof(manager));
            _reminderService = reminderService ?? throw new ArgumentNullException(nameof(reminderService));
            ClearDetailFields();
            RefreshList();
        }

        private void RefreshList()
        {
            LvTasks.ItemsSource = null;
            LvTasks.ItemsSource = _taskManager.GetAll().OrderBy(t => t.DueDate).ToList();
        }

        private void ClearDetailFields()
        {
            _selected = null;
            TbTitle.Text = "";
            TbDescription.Text = "";
            DpDueDate.SelectedDate = DateTime.Now.Date;
            TbDueTime.Text = DateTime.Now.ToString("HH:mm");
            CbRemind.IsChecked = false;
            TbRemindMinutes.Text = "10";
        }

        private void LvTasks_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LvTasks.SelectedItem is TaskItem item)
            {
                _selected = item;
                TbTitle.Text = item.Title;
                TbDescription.Text = item.Description;
                DpDueDate.SelectedDate = item.DueDate.Date;
                TbDueTime.Text = item.DueDate.ToString("HH:mm");
                CbRemind.IsChecked = item.Remind;
                TbRemindMinutes.Text = item.ReminderMinutesBefore.ToString();
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClearDetailFields();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (_selected == null)
            {
                MessageBox.Show("Select a task to edit.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (LvTasks.SelectedItem is TaskItem item)
            {
                if (MessageBox.Show($"Delete task '{item.Title}'?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    _taskManager.Remove(item.Id);
                    RefreshList();
                    ClearDetailFields();
                }
            }
            else
            {
                MessageBox.Show("Select a task to delete.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TbTitle.Text))
            {
                MessageBox.Show("Please provide a title for the task.", "Validation", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DateTime date = DpDueDate.SelectedDate ?? DateTime.Now.Date;
            if (!TimeSpan.TryParse(TbDueTime.Text.Trim(), out TimeSpan timeSpan))
            {
                MessageBox.Show("Time format invalid. Use HH:mm", "Validation", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DateTime due = date.Date + timeSpan;

            if (!int.TryParse(TbRemindMinutes.Text.Trim(), out int remindMin) || remindMin < 0)
            {
                MessageBox.Show("Reminder minutes must be a non-negative integer.", "Validation", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (_selected == null)
            {
                var task = new TaskItem
                {
                    Title = TbTitle.Text.Trim(),
                    Description = TbDescription.Text.Trim(),
                    DueDate = due,
                    Remind = CbRemind.IsChecked == true,
                    ReminderMinutesBefore = remindMin
                };
                _taskManager.Add(task);
            }
            else
            {
                _selected.Title = TbTitle.Text.Trim();
                _selected.Description = TbDescription.Text.Trim();
                _selected.DueDate = due;
                _selected.Remind = CbRemind.IsChecked == true;
                _selected.ReminderMinutesBefore = remindMin;
                _taskManager.Update(_selected);
            }

            RefreshList();
            MessageBox.Show("Task saved.", "Saved", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BtnMarkDone_Click(object sender, RoutedEventArgs e)
        {
            if (LvTasks.SelectedItem is TaskItem item)
            {
                item.Completed = !item.Completed;
                _taskManager.Update(item);
                RefreshList();
            }
            else
            {
                MessageBox.Show("Select a task to toggle completion.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}

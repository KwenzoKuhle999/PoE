﻿-- Create database (only if you need a dedicated DB)
IF DB_ID('poe_p2_tasks') IS NULL
BEGIN
    CREATE DATABASE poe3_tasks;
END
GO

USE poe_p2_tasks;
GO

-- Create table: demo_tasks (includes reminder and notification columns)
IF OBJECT_ID('dbo.demo_tasks','U') IS NULL
BEGIN
    CREATE TABLE dbo.demo_tasks (
        task_id                  INT IDENTITY(1,1) PRIMARY KEY,
        task_name                VARCHAR(255) NOT NULL,
        task_description         VARCHAR(MAX) NULL,
        task_dueDate             DATETIME2 NULL,
        task_status              VARCHAR(50) NULL,
        remind                   BIT NOT NULL DEFAULT(0),
        reminder_minutes_before  INT NULL DEFAULT(10),
        completed                BIT NOT NULL DEFAULT(0),
        last_notified_utc        DATETIME2 NULL
    );
END
GO

INSERT INTO dbo.demo_tasks (task_name, task_description, task_dueDate, task_status, remind, reminder_minutes_before, completed)
VALUES (@task_name, @task_description, @task_dueDate, @task_status, @remind, @reminder_minutes_before, @completed);

-- To get the newly inserted identity (in the same batch)
SELECT SCOPE_IDENTITY() AS new_id;

SELECT task_id, task_name, task_description, task_dueDate, task_status, remind, reminder_minutes_before, completed, last_notified_utc
FROM dbo.demo_tasks
ORDER BY task_dueDate;

SELECT *
FROM dbo.demo_tasks
WHERE task_id = @task_id;

UPDATE dbo.demo_tasks
SET task_name = @task_name,
    task_description = @task_description,
    task_dueDate = @task_dueDate,
    task_status = @task_status,
    remind = @remind,
    reminder_minutes_before = @reminder_minutes_before,
    completed = @completed,
    last_notified_utc = @last_notified_utc
WHERE task_id = @task_id;


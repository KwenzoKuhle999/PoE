﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Part3
{
	public class AudioManager
	{
		/// <summary>
		/// Handles loading and playing the generated WAV file.
		/// Expects "greeting.wav" next to the application executable, or provide full path.
		/// </summary>
		public void PlayGreetingAudio()
		{
			try
			{
				string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "greeting.wav");
				if (File.Exists(path))
				{
					MediaPlayer player = new MediaPlayer();
					player.Open(new Uri(path, UriKind.Absolute));
					player.Play();
				}
			}
			catch (Exception ex)
			{
				System.Diagnostics.Debug.WriteLine($"Error playing audio: {ex.Message}");
			}
		}
	}
}
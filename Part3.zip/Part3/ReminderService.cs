﻿using System;
using System.Collections.Generic;
using System.Text;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Threading;

namespace Part3
{
    public class ReminderService : IDisposable
    {
        private readonly TaskManager _taskManager;
        private readonly DispatcherTimer _timer;
        private readonly TimeSpan _checkInterval = TimeSpan.FromSeconds(30);

        public ReminderService(TaskManager taskManager)
        {
            _taskManager = taskManager ?? throw new ArgumentNullException(nameof(taskManager));
            _timer = new DispatcherTimer { Interval = _checkInterval };
            _timer.Tick += Timer_Tick;
        }

        public void Start() => _timer.Start();

        public void Stop() => _timer.Stop();

        private void Timer_Tick(object? sender, EventArgs e)
        {
            try
            {
                var nowUtc = DateTime.UtcNow;
                foreach (var task in _taskManager.GetAll().Where(t => t.Remind && !t.Completed))
                {
                    var reminderTimeUtc = task.DueDate.ToUniversalTime().AddMinutes(-task.ReminderMinutesBefore);
                    // Check if now has passed the reminder time and not notified recently
                    if (nowUtc >= reminderTimeUtc)
                    {
                        // avoid repeated notifications within a short window (e.g., 30 minutes)
                        if (task.LastNotifiedUtc == null || (nowUtc - task.LastNotifiedUtc.Value).TotalMinutes > 30)
                        {
                            Notify(task);
                            task.LastNotifiedUtc = nowUtc;
                            _taskManager.Update(task); // persist last-notified
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"ReminderService error: {ex.Message}");
            }
        }

        private void Notify(TaskItem task)
        {
            // UI-level notification. You can replace with Toast/NotifyIcon later.
            Application.Current.Dispatcher.Invoke(() =>
            {
                string title = $"Reminder: {task.Title}";
                string body = $"Due: {task.DueDate:G}\n{(string.IsNullOrWhiteSpace(task.Description) ? "" : task.Description)}";
                MessageBox.Show(body, title, MessageBoxButton.OK, MessageBoxImage.Information);
            });
        }

        public void Dispose()
        {
            _timer.Tick -= Timer_Tick;
            _timer.Stop();
        }
    }
}
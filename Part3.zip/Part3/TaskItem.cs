﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Part3
{
    public class TaskItem
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Title { get; set; } = "";
        public string Description { get; set; } = "";
        public DateTime DueDate { get; set; } = DateTime.Now.AddHours(1);
        public bool Remind { get; set; } = false;
        // Minutes before DueDate when reminder should fire
        public int ReminderMinutesBefore { get; set; } = 10;
        public bool Completed { get; set; } = false;

        // For preventing repeated reminders during the same session/period
        public DateTime? LastNotifiedUtc { get; set; } = null;
    }
}
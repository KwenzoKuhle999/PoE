﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;


namespace Part3
{
    public class TaskManager
    {
        private readonly string _filePath = "tasks.json";
        private readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions
        {
            WriteIndented = true,
            Converters = { new JsonStringEnumConverter() }
        };

        private List<TaskItem> _tasks = new List<TaskItem>();

        public TaskManager()
        {
            Load();
        }

        public IReadOnlyList<TaskItem> GetAll() => _tasks.AsReadOnly();

        public void Add(TaskItem item)
        {
            _tasks.Add(item);
            Save();
        }

        public void Update(TaskItem item)
        {
            var index = _tasks.FindIndex(t => t.Id == item.Id);
            if (index >= 0) _tasks[index] = item;
            Save();
        }

        public void Remove(Guid id)
        {
            _tasks.RemoveAll(t => t.Id == id);
            Save();
        }

        public void Save()
        {
            try
            {
                var json = JsonSerializer.Serialize(_tasks, _jsonOptions);
                File.WriteAllText(_filePath, json);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"TaskManager Save error: {ex.Message}");
            }
        }

        public void Load()
        {
            try
            {
                if (!File.Exists(_filePath))
                {
                    _tasks = new List<TaskItem>();
                    return;
                }

                var json = File.ReadAllText(_filePath);
                _tasks = JsonSerializer.Deserialize<List<TaskItem>>(json, _jsonOptions) ?? new List<TaskItem>();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"TaskManager Load error: {ex.Message}");
                _tasks = new List<TaskItem>();
            }
        }
    }
}

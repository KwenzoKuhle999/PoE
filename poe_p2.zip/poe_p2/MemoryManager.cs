﻿using System;
using System.IO;

namespace poe_p2
{
    public class MemoryManager
    {
        private readonly string _memoryFile = "memory.txt";

        public void SaveFavoriteTopic(string message, ref string currentTopic)
        {
            string topic = message.Replace("i am interested in", "").Trim();
            if (string.IsNullOrWhiteSpace(topic)) topic = currentTopic;
            if (string.IsNullOrEmpty(topic)) topic = "General Security";

            currentTopic = topic;
            File.WriteAllText(_memoryFile, topic);
        }

        public string GetSavedTopic()
        {
            if (File.Exists(_memoryFile))
            {
                return File.ReadAllText(_memoryFile);
            }
            return null;
        }
    }
}
﻿using System;

namespace poe_p2
{
    public class SentimentAnalyzer
    {
        public string DetectSentiment(string message)
        {
            if (string.IsNullOrEmpty(message)) return "";

            if (message.Contains("worried") || message.Contains("anxious") || message.Contains("unsure") ||
                message.Contains("nervous") || message.Contains("scared") || message.Contains("afraid") || message.Contains("terrified"))
                return "worried";

            if (message.Contains("frustrated") || message.Contains("annoyed") || message.Contains("angry") ||
                message.Contains("stuck") || message.Contains("hate") || message.Contains("tired of") ||
                message.Contains("confused") || message.Contains("don't understand") || message.Contains("lost") || message.Contains("overwhelmed"))
                return "Frustrated";

            if (message.Contains("help") || message.Contains("need assistance") || message.Contains("can you explain") || message.Contains("more info"))
                return "worried";

            if (message.Contains("thank you") || message.Contains("thanks") || message.Contains("appreciate it") || message.Contains("grateful"))
                return "grateful";

            if (message.Contains("excited") || message.Contains("looking forward") || message.Contains("can't wait") || message.Contains("eager"))
                return "excited";

            if (message.Contains("bored") || message.Contains("not interested") || message.Contains("dull") || message.Contains("unengaging"))
                return "bored";

            if (message.Contains("curious") || message.Contains("interested") || message.Contains("want to learn") || message.Contains("fascinated"))
                return "curious";

            if (message.Contains("confident") || message.Contains("sure") || message.Contains("got it") || message.Contains("understand"))
                return "confident";

            if (message.Contains("sad") || message.Contains("disappointed") || message.Contains("unhappy") || message.Contains("down"))
                return "sad";

            return "";
        }

        public string GetSentimentSupport(string sentiment, string userName)
        {
            if (sentiment == "worried")
                return $"Hey, take a deep breath, {userName}. Cybersecurity threats sound incredibly terrifying, but they are completely manageable once you break down how they work. Let's look at this closely:\n\n";

            if (sentiment == "Frustrated")
                return $"I completely get your frustration, {userName}. Dealing with security alerts, configuration loops, or scam links can feel like a headache. Let's solve this cleanly and step-by-step:\n\n";

            return "";
        }

        public bool IsFollowUp(string message)
        {
            return message.Contains("more info") || message.Contains("tell me more") ||
                   message.Contains("can you explain") || message.Contains("i want to know more") ||
                   message.Contains("elaborate") || message.Contains("details");
        }
    }
}

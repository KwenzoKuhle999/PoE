﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace poe_p2
{
    public partial class MainWindow : Window
    {
        private string userName = "";
        private string currentTopic = "";

        // Internal Helpers Orchestrated by UI
        private readonly QuizManager _quizManager;
        private readonly SentimentAnalyzer _sentimentAnalyzer;
        private readonly TopicDetector _topicDetector;
        private readonly MemoryManager _memoryManager;

        private readonly Dictionary<string, int> _topicTrackingCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        public MainWindow()
        {
            InitializeComponent();

            // Instantiating components
            _quizManager = new QuizManager();
            _sentimentAnalyzer = new SentimentAnalyzer();
            _topicDetector = new TopicDetector();
            _memoryManager = new MemoryManager();

           
        }

        

        public void Start_Click(object sender, RoutedEventArgs e)
        {
            WelcomeGrid.Visibility = Visibility.Collapsed;
            NameGrid.Visibility = Visibility.Visible;
        }

        public void Submit_Click(object sender, RoutedEventArgs e)
        {
            string name = NameTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(name))
            {
                ErrorText.Text = "Please enter a name so I know who I am talking to.";
                return;
            }

            if (!Regex.IsMatch(name, @"^[a-zA-Z\s]+$"))
            {
                ErrorText.Text = "Please write a standard name using letters only.";
                return;
            }

            userName = name;
            ErrorText.Text = "";

            NameGrid.Visibility = Visibility.Collapsed;
            ChatGrid.Visibility = Visibility.Visible;

            TxtWelcomeStatus.Text = $"LOGGED IN AS: {userName.ToUpper()} | COMMUNICATIONS CORE SECURED";
            AppendColorCodedText("SYSTEM", $"Connection initialized. Hi {userName}! I'm your cybersecurity virtual mentor. Feel free to ask me anything about network safety, phishing, or cybersecurity threats in general.", Brushes.DarkGray);
            TxtUserInput.Focus();
        }

        public void Send_Click(object sender, RoutedEventArgs e) => TransmitUserConsoleInput();
        private void TxtUserInput_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) TransmitUserConsoleInput(); }

        private void TransmitUserConsoleInput()
        {
            string message = TxtUserInput.Text?.Trim();
            if (string.IsNullOrEmpty(message))
            {
                AppendColorCodedText("SYSTEM", "The input is empty. Type a question or topic so we can discuss it!", Brushes.Crimson);
                TxtUserInput.Clear();
                return;
            }

            AppendColorCodedText(userName, message, Brushes.White);
            TxtUserInput.Clear();

            string botResponse = ChatBotResponseProcessing(message);
            AppendColorCodedText("ASSISTANT", botResponse, Brushes.LimeGreen);
        }

        public string ChatBotResponseProcessing(string rawMessage)
        {
            string cleanMessage = rawMessage.ToLower();
            string sentiment = _sentimentAnalyzer.DetectSentiment(cleanMessage);
            bool moreInfo = _sentimentAnalyzer.IsFollowUp(cleanMessage);

            if (cleanMessage.Contains("interested in"))
            {
                _memoryManager.SaveFavoriteTopic(cleanMessage, ref currentTopic);
                return $"Got it! I have updated my memory settings. I will remember that your favorite topic is: {currentTopic.ToUpper()}. We can run customized quizzes on this anytime.";
            }

            if (cleanMessage.Contains("favorite topic"))
            {
                string savedTopic = _memoryManager.GetSavedTopic();
                if (savedTopic != null)
                {
                    return $"Checking my local storage... Ah, yes! Your saved favorite cybersecurity topic is recorded as: {savedTopic.ToUpper()}.";
                }
                return "I don't have a favorite topic saved for you in my storage yet. Tell me what you like by typing 'I am interested in [topic]'.";
            }

            string topic = _topicDetector.DetectTopicToken(cleanMessage);

            if (string.IsNullOrEmpty(topic) && moreInfo && !string.IsNullOrEmpty(currentTopic))
            {
                topic = currentTopic;
            }

            if (!string.IsNullOrEmpty(topic))
            {
                currentTopic = topic;

                if (!_topicTrackingCounts.ContainsKey(topic)) _topicTrackingCounts[topic] = 0;
                _topicTrackingCounts[topic]++;

                string supportHeader = _sentimentAnalyzer.GetSentimentSupport(sentiment, userName);
                string coreOutput = _topicDetector.BuildResponse(topic, supportHeader);

                if (_topicTrackingCounts[topic] > 2)
                {
                    coreOutput += $"\n\n [TERMINAL NOTE]: {userName}, I noticed you are deeply focused on {topic.ToUpper()} today. I've updated the Assessment Module on the right to match this topic if you want to test your skills!";
                }
                return coreOutput;
            }

            string generalSupportHeader = _sentimentAnalyzer.GetSentimentSupport(sentiment, userName);
            if (moreInfo)
            {
                return $"{generalSupportHeader}I'd love to explain further, but I need a little more direction. Which security topic are we diving into? Let me know if you want to talk about phishing variants or malware defenses.";
            }

            return $"{generalSupportHeader}I am here to help you learn about cybersecurity concepts. Try asking me a question about how phishing works, what malware does, or how to keep your personal devices safe.";
        }

        private void AppendColorCodedText(string headerLabel, string contentString, Brush brushColor)
        {
            if (TxtConversationStream == null || string.IsNullOrEmpty(contentString)) return;

            TxtConversationStream.Dispatcher.Invoke(() =>
            {
                TextPointer pointerEnd = TxtConversationStream.Document.ContentEnd;
                TextRange inlineRange = new TextRange(pointerEnd, pointerEnd)
                {
                    Text = $"$ [{headerLabel}]: {contentString}\n\n"
                };
                inlineRange.ApplyPropertyValue(TextElement.ForegroundProperty, brushColor);
                ChatScrollContainer?.ScrollToEnd();
            });
        }

        #region ASSESSMENT MODULE LOGIC

        private void BtnInitializeQuiz_Click(object sender, RoutedEventArgs e)
        {
            BtnInitializeQuiz.Visibility = Visibility.Collapsed;
            BtnSubmitAnswer.Visibility = Visibility.Visible;

            RadioOptionA.Visibility = Visibility.Visible;
            RadioOptionB.Visibility = Visibility.Visible;
            RadioOptionC.Visibility = Visibility.Visible;

            string targetedEvaluationKey = !string.IsNullOrEmpty(currentTopic) ? currentTopic : "general";
            _quizManager.BuildDynamicQuiz(targetedEvaluationKey);
            PresentStructuredAssessmentQuestion();
        }

        private void PresentStructuredAssessmentQuestion()
        {
            if (_quizManager.HasMoreQuestions)
            {
                var questionModel = _quizManager.GetCurrentQuestion();
                TxtAssessmentQuestion.Text = $"Quiz Progress Node [{_quizManager.CurrentQuestionIndex + 1}/{_quizManager.AssessmentBank.Count}]:\n\n{questionModel.PromptQueryText}";

                RadioOptionA.Content = questionModel.SelectionA;
                RadioOptionB.Content = questionModel.SelectionB;
                RadioOptionC.Content = questionModel.SelectionC;

                RadioOptionA.IsChecked = RadioOptionB.IsChecked = RadioOptionC.IsChecked = false;
            }
            else
            {
                FinalizeAssessmentMetricCalculations();
            }
        }

        private void BtnSubmitAnswer_Click(object sender, RoutedEventArgs e)
        {
            char trackedSelectionToken = ' ';
            if (RadioOptionA.IsChecked == true) trackedSelectionToken = 'A';
            else if (RadioOptionB.IsChecked == true) trackedSelectionToken = 'B';
            else if (RadioOptionC.IsChecked == true) trackedSelectionToken = 'C';

            if (trackedSelectionToken == ' ')
            {
                MessageBox.Show("Please check one of the interactive options fields before submitting your answer.", "Input Blank", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var currentQuestion = _quizManager.GetCurrentQuestion();
            bool isCorrect = _quizManager.SubmitAnswer(trackedSelectionToken);

            if (isCorrect)
            {
                MessageBox.Show("Awesome job! Your choice aligns with secure network standards.", "Correct!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show($"That wasn't quite right. The ideal protective path was Option {currentQuestion.TargetAnswerKey}.", "Incorrect Option", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }

            PresentStructuredAssessmentQuestion();
        }

        private void FinalizeAssessmentMetricCalculations()
        {
            RadioOptionA.Visibility = RadioOptionB.Visibility = RadioOptionC.Visibility = Visibility.Collapsed;
            BtnSubmitAnswer.Visibility = Visibility.Collapsed;

            BtnInitializeQuiz.Visibility = Visibility.Visible;
            BtnInitializeQuiz.Content = "Start New Quiz";

            TxtAssessmentQuestion.Text = $" KNOWLEDGE ASSESSMENT COMPLETE\n\nOperator Name: {userName}\nTested Subject Focus: {currentTopic.ToUpper()}\nYour Score: {_quizManager.UserPerformanceScore} out of {_quizManager.AssessmentBank.Count} correctly answered.";
        }

        #endregion
    }
}
﻿using System;
using System.IO;
using System.Windows.Media;

using System.Windows;

namespace poe_p2
{
    public class AudioManager
    {
   
        /// <summary>
        /// Handles loading and playing the generated WAV file.
        /// </summary>
        public void PlayGreetingAudio()
        {
            try
            {
                if (File.Exists("C: \\Users\\MzimaseM\\sourc\\repos\\poe_p2\\greeting.wav"))
                {
                    MediaPlayer player = new MediaPlayer();
                    player.Open(new Uri(("C: \\Users\\MzimaseM\\sourc\\repos\\poe_p2\\greeting.wav"))); 
                    player.Play();
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error playing audio: {ex.Message}");
            }
        }
    }
}
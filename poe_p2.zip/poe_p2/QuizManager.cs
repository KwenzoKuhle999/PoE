﻿using System;
using System.Collections.Generic;

namespace poe_p2
{
    public class WpfQuizQuestion
    {
        public string PromptQueryText { get; set; }
        public string SelectionA { get; set; }
        public string SelectionB { get; set; }
        public string SelectionC { get; set; }
        public char TargetAnswerKey { get; set; }

        public WpfQuizQuestion(string prompt, string a, string b, string c, char exactKey)
        {
            PromptQueryText = prompt;
            SelectionA = a;
            SelectionB = b;
            SelectionC = c;
            TargetAnswerKey = exactKey;
        }
    }

    public class QuizManager
    {
        public List<WpfQuizQuestion> AssessmentBank { get; private set; }
        public int CurrentQuestionIndex { get; private set; }
        public int UserPerformanceScore { get; private set; }

        public bool HasMoreQuestions => CurrentQuestionIndex < AssessmentBank.Count;

        public void BuildDynamicQuiz(string topic)
        {
            AssessmentBank = new List<WpfQuizQuestion>();
            CurrentQuestionIndex = 0;
            UserPerformanceScore = 0;

            string searchTopic = topic.ToLower().Trim();

            if (searchTopic == "phishing")
            {
                AssessmentBank.Add(new WpfQuizQuestion("What indicates that a received corporate email might actually be a phishing attempt?", "It contains an unexpected, highly urgent request asking you to verify password credentials.", "It has a regular signature block from a verified administrative team.", "The message notes that your monthly storage usage is normal.", 'A'));
                AssessmentBank.Add(new WpfQuizQuestion("What is the safest rule to follow if you find a suspicious link in an text message?", "Click it to see where it redirects, then close it fast.", "Ignore the message completely or call the sender directly using an official number to double-check.", "Forward it immediately to all your friends to see if they got it too.", 'B'));
            }
            else if (searchTopic == "malware")
            {
                AssessmentBank.Add(new WpfQuizQuestion("If a device suddenly displays a popup stating all your database items are encrypted and demands payment, what is this?", "A common file compression notification utility error.", "A severe Ransomware infection attack scenario.", "A standard web browser cookies warning statement.", 'B'));
                AssessmentBank.Add(new WpfQuizQuestion("How does a Trojan horse style application deceive computer users?", "It crashes your monitor screens physically.", "It disguises itself as a useful, harmless game or tool while performing malicious theft in the background.", "It increases internet speeds temporarily to look efficient.", 'B'));
            }
            else if (searchTopic == "sql injection")
            {
                AssessmentBank.Add(new WpfQuizQuestion("What is a common sign that a website might be vulnerable to SQL injection?", "The website has a very colorful design.", "The URL contains parameters that are not properly sanitized, such as 'id=1' or 'search=keyword'.", "The website loads very quickly.", 'B'));
                AssessmentBank.Add(new WpfQuizQuestion("Which practice can help prevent SQL injection attacks?", "Using parameterized queries or prepared statements.", "Allowing users to input raw SQL commands.", "Disabling all database logging.", 'A'));
            }
            else if (searchTopic == "social engineering")
            {
                AssessmentBank.Add(new WpfQuizQuestion("What is a common tactic used in social engineering attacks?", "Using complex encryption algorithms.", "Creating a sense of urgency to trick victims into acting quickly without thinking.", "Installing antivirus software.", 'B'));
                AssessmentBank.Add(new WpfQuizQuestion("How can you protect yourself from social engineering attacks?", "By being cautious of unsolicited requests for sensitive information and verifying the identity of the requester.", "By sharing your passwords with trusted friends.", "By ignoring all emails from unknown senders.", 'A'));
            }
            else if (searchTopic == "password")
            {
                AssessmentBank.Add(new WpfQuizQuestion("What is a strong password?", "A password that is at least 12 characters long, includes a mix of letters, numbers, and special characters.", "A password that is easy to remember, like 'password123'.", "A password that is the same as your username.", 'A'));
                AssessmentBank.Add(new WpfQuizQuestion("What is the purpose of multi-factor authentication (MFA)?", "To allow users to log in without a password.", "To provide an additional layer of security by requiring a second form of verification.", "To automatically change your password every month.", 'B'));
            }
            else
            {
                // Fallback / General option
                AssessmentBank.Add(new WpfQuizQuestion("What does the concept of 'Defense-in-Depth' mean to a system builder?", "Running only one strong anti-malware application and nothing else.", "Setting up multiple layered safety strategies covering networks, software patches, and human knowledge training.", "Deleting all files on your local desktop every night.", 'B'));
                AssessmentBank.Add(new WpfQuizQuestion("Why is using Multi-Factor Authentication (MFA) heavily recommended today?", "It creates an extra layer of login verification checks, making it much harder for thieves who steal passwords to get in.", "It automatically blocks all incoming email marketing ads.", "It helps clean temporary cached memory lines.", 'A'));
            }
        }

        public WpfQuizQuestion GetCurrentQuestion()
        {
            if (HasMoreQuestions) return AssessmentBank[CurrentQuestionIndex];
            return null;
        }

        public bool SubmitAnswer(char answer)
        {
            var question = GetCurrentQuestion();
            bool correct = question != null && question.TargetAnswerKey == answer;
            if (correct) UserPerformanceScore++;
            CurrentQuestionIndex++;
            return correct;
        }
    }
}
